
export interface ClinicalFile {
  id: string;
  name: string;
  size: string;
  date: string;
  type: 'pdf' | 'image';
  url: string;
  base64?: string;
}

export type AppView = 'PATIENT' | 'PROFESSIONAL' | 'ADMIN';

export interface Service {
  id: string;
  name: string;
  price: number;
  duration: number; // en minutos
  description: string;
  image?: string;
}

export interface Transaction {
  id: string;
  date: string;
  amount: number;
  description: string;
  type: 'Ingreso' | 'Gasto';
}

export type SubscriptionStatus = 'active' | 'paused' | 'trial';

// Added missing Vitals interface
export interface Vitals {
  heartRate: number;
  systolic: number;
  diastolic: number;
  temperature: number;
  oxygenSaturation: number;
  respiratoryRate?: number;
  weight?: number;
  height?: number;
  bmi?: number;
  glucose?: number;
}

// Added missing SessionLog interface
export interface SessionLog {
  id: string;
  date: string;
  note: string;
}

// Added missing CustomField interface
export interface CustomField {
  label: string;
  value: string;
}

export interface ProfessionalProfile {
  id: string;
  slug: string;
  name: string;
  email: string;
  password?: string;
  tempCode?: string;
  needsPasswordReset: boolean;
  paymentEnabled: boolean; // Opcional: El profesional decide si cobrar
  isVerified: boolean;
  isSubscribed: boolean;
  subscriptionStatus: SubscriptionStatus; // Nuevo: Control de estado
  trialEndDate?: string; // Nuevo: Fin de 30 días gratis
  nextBillingDate?: string; // Nuevo: Fecha de cobro
  subscriptionLink?: string; // Link de pago personalizado
  specialty: string;
  city: string;
  bio: string;
  avatar?: string;
  workingHours: {
    start: string;
    end: string;
  };
  schedule?: {
    [key: number]: { // 0: Sunday, 1: Monday, ..., 6: Saturday
      active: boolean;
      start: string;
      end: string;
    }
  };
  modalities: {
    online: boolean;
    inPerson: boolean;
    home: boolean;
  };
  services: Service[];
  isPublic: boolean;
  createdAt: string;
}

export interface Appointment {
  id: string;
  patientId?: string;
  patientName: string;
  patientPhone?: string;
  doctorName: string;
  specialty: string;
  serviceName: string;
  date: string;
  time: string;
  duration: number;
  type: 'Presencial' | 'Online' | 'Domicilio' | 'Personal';
  status: 'Confirmado' | 'Pendiente' | 'Finalizado' | 'Cancelado' | 'En Sesión' | 'Bloqueado' | 'Llegado';
  price: number;
  paymentStatus: 'Pagado' | 'Pendiente';
  notes?: string;
  color?: string;
  category: 'Medical' | 'Personal';
  professionalId?: string;
  bookingSource?: 'web' | 'presencial' | 'telefono' | 'whatsapp' | 'referido';
  paidAt?: string;
  paymentAmount?: number;
}

export interface Notification {
  id: string;
  title: string;
  time: string;
  type: 'appointment' | 'payment' | 'system';
  read: boolean;
}

export interface Patient {
  id: string;
  name: string;
  rut: string;
  age: number;
  gender: string;
  email: string;
  phone: string;
  status: 'Confirmado' | 'Pendiente' | 'En Sesión' | 'Llegado' | 'Archivado' | 'En Tratamiento' | 'Alta Médica' | 'Nuevo';
  prevision: string;
  birthDate: string;
  address: string;
  allergies: string[];
  medicalHistory: string;
  // Updated from any to Vitals
  vitals?: Vitals;
  attachments: ClinicalFile[];
  sessionLogs?: SessionLog[];
  customFields: CustomField[];
  archived: boolean;
  risk: 'Bajo' | 'Medio' | 'Alto';
  avatar?: string;
  // Added diagnoses to satisfy ClinicalRecord usage
  diagnoses?: string;
  lastVisit?: string;
  emergencyContact?: string;
  soap?: { subjective: string; objective: string; assessment: string; plan: string };
  goals?: { id: string; name: string; description: string; progress: number; status: string; color: string }[];
}

export interface ClinicalTemplate {
  id: string;
  name: string;
  fields: string[];
}
