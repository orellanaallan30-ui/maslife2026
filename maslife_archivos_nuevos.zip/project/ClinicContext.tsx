// ClinicContext.tsx — v3: multi-profesional real, sin hardcodeos, state limpio
import React, {
  createContext, useContext, useState, useEffect,
  useCallback, ReactNode
} from 'react';
import {
  ProfessionalProfile, Appointment, Patient,
  Transaction, AppView, ClinicalTemplate, Notification
} from './types';
import {
  supabase,
  getProfessional, saveProfessional,
  getPatients, savePatient,
  getAppointments, saveAppointment, deleteAppointment as dbDeleteAppointment,
  getTransactions, saveTransaction, deleteTransaction as dbDeleteTransaction,
  signOutProfessional, getActiveSession, migrateFromLocalStorage,
} from './supabaseService';

// ── Interfaz del contexto ─────────────────────────────────────
interface ClinicContextType {
  loggedPro:          ProfessionalProfile | null;
  professionals:      ProfessionalProfile[];
  appointments:       Appointment[];
  patients:           Patient[];
  manualTransactions: Transaction[];
  isLoading:          boolean;
  notifications:      Notification[];
  templates:          ClinicalTemplate[];
  isAdmin:            boolean;

  setLoggedPro:           (pro: ProfessionalProfile | null) => void;
  setIsAdmin:             (v: boolean) => void;
  setAppointments:        React.Dispatch<React.SetStateAction<Appointment[]>>;
  setPatients:            React.Dispatch<React.SetStateAction<Patient[]>>;
  setManualTransactions:  React.Dispatch<React.SetStateAction<Transaction[]>>;
  setNotifications:       React.Dispatch<React.SetStateAction<Notification[]>>;
  setTemplates:           React.Dispatch<React.SetStateAction<ClinicalTemplate[]>>;
  setProfessionals:       React.Dispatch<React.SetStateAction<ProfessionalProfile[]>>;
  updatePro:              (updated: ProfessionalProfile) => Promise<void>;
  logout:                 (navigate: (p: string) => void, view: AppView) => Promise<void>;
  addAppointment:         (app: Appointment) => Promise<void>;
  updateAppointment:      (app: Appointment) => Promise<void>;
  deleteAppointment:      (id: string) => Promise<void>;
  addPatient:             (p: Patient) => Promise<void>;
  updatePatient:          (p: Patient) => Promise<void>;
  deleteTransaction:      (id: string) => Promise<void>;
  addTransaction:         (t: Transaction) => Promise<void>;
  refreshData:            () => Promise<void>;
}

const ClinicContext = createContext<ClinicContextType | undefined>(undefined);

// ── Estado vacío para resetear al hacer logout ────────────────
const EMPTY_STATE = { appointments: [], patients: [], manualTransactions: [] };

export const ClinicProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [loggedPro, setLoggedProState] = useState<ProfessionalProfile | null>(null);
  const [professionals, setProfessionals]         = useState<ProfessionalProfile[]>([]);
  const [appointments, setAppointments]           = useState<Appointment[]>([]);
  const [patients, setPatients]                   = useState<Patient[]>([]);
  const [manualTransactions, setManualTransactions] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading]                 = useState(true);
  const [templates, setTemplates]                 = useState<ClinicalTemplate[]>([]);
  const [notifications, setNotifications]         = useState<Notification[]>([
    { id: '1', title: 'Conectado a MasLife Cloud ☁️', time: 'Ahora', type: 'system', read: false },
  ]);
  const [isAdmin, setIsAdmin] = useState<boolean>(
    () => localStorage.getItem('maslife_admin_auth') === 'true'
  );

  // ── Carga de datos por profesional ────────────────────────
  // FIX CRÍTICO: se llama al hacer login/logout, no solo al montar
  const loadProData = useCallback(async (pro: ProfessionalProfile) => {
    setIsLoading(true);
    try {
      const proId = pro.id;
      const [pats, apps, txs] = await Promise.all([
        getPatients(proId),
        getAppointments(proId),
        getTransactions(proId),
      ]);
      setPatients(pats);
      setAppointments(apps);
      setManualTransactions(txs);

      // Migración única desde localStorage si la nube está vacía
      if (pats.length === 0 && apps.length === 0) {
        await migrateFromLocalStorage(proId);
        const [pats2, apps2, txs2] = await Promise.all([
          getPatients(proId), getAppointments(proId), getTransactions(proId),
        ]);
        setPatients(pats2); setAppointments(apps2); setManualTransactions(txs2);
      }
    } catch (err) {
      console.error('[ClinicContext] Error cargando datos:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // ── Arranque: recuperar sesión existente ──────────────────
  useEffect(() => {
    const init = async () => {
      const activePro = await getActiveSession();
      if (activePro) {
        setLoggedProState(activePro);
        setProfessionals([activePro]);
        await loadProData(activePro);
      } else {
        setIsLoading(false);
      }
    };
    init();

    // Escuchar cambios de sesión de Supabase Auth (token refresh, logout externo)
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_OUT') {
        setLoggedProState(null);
        setProfessionals([]);
        setAppointments(EMPTY_STATE.appointments);
        setPatients(EMPTY_STATE.patients);
        setManualTransactions(EMPTY_STATE.manualTransactions);
      }
      if (event === 'TOKEN_REFRESHED' && session?.user) {
        // Token renovado: refrescar perfil silenciosamente
        const pro = await getProfessional(session.user.id);
        if (pro) setLoggedProState(pro);
      }
      if (event === 'PASSWORD_RECOVERY') {
        // Redirigir a la pantalla de nueva contraseña
        window.location.hash = '/pro/reset-password';
      }
    });

    return () => subscription.unsubscribe();
  }, [loadProData]);

  // ── setLoggedPro público ──────────────────────────────────
  const setLoggedPro = useCallback((pro: ProfessionalProfile | null) => {
    setLoggedProState(pro);
    if (pro) {
      setProfessionals([pro]);
      loadProData(pro);
    } else {
      setAppointments([]); setPatients([]); setManualTransactions([]);
      setProfessionals([]);
    }
  }, [loadProData]);

  // ── refreshData ───────────────────────────────────────────
  const refreshData = useCallback(async () => {
    if (loggedPro) await loadProData(loggedPro);
  }, [loggedPro, loadProData]);

  // ── updatePro ─────────────────────────────────────────────
  const updatePro = useCallback(async (updated: ProfessionalProfile) => {
    setProfessionals(prev => prev.map(p => p.id === updated.id ? updated : p));
    if (loggedPro?.id === updated.id) setLoggedProState(updated);
    await saveProfessional(updated);
  }, [loggedPro]);

  // ── Logout ────────────────────────────────────────────────
  const logout = useCallback(async (navigate: (p: string) => void, view: AppView) => {
    if (view === 'ADMIN') {
      setIsAdmin(false);
      localStorage.removeItem('maslife_admin_auth');
      navigate('/admin/login');
    } else {
      await signOutProfessional();
      setLoggedProState(null);
      setProfessionals([]);
      setAppointments([]); setPatients([]); setManualTransactions([]);
      navigate('/pro/login');
    }
  }, []);

  // ── Citas ─────────────────────────────────────────────────
  const addAppointment = useCallback(async (app: Appointment) => {
    if (!loggedPro) return;
    const withPro = { ...app, professionalId: loggedPro.id };
    setAppointments(prev => [...prev, withPro]);
    await saveAppointment(withPro);
  }, [loggedPro]);

  const updateAppointment = useCallback(async (app: Appointment) => {
    setAppointments(prev => prev.map(a => a.id === app.id ? app : a));
    await saveAppointment(app);
  }, []);

  const deleteAppointment = useCallback(async (id: string) => {
    setAppointments(prev => prev.filter(a => a.id !== id));
    await dbDeleteAppointment(id);
  }, []);

  // ── Pacientes ──────────────────────────────────────────────
  const addPatient = useCallback(async (p: Patient) => {
    if (!loggedPro) return;
    setPatients(prev => [...prev, p]);
    await savePatient(p, loggedPro.id);
  }, [loggedPro]);

  const updatePatient = useCallback(async (p: Patient) => {
    if (!loggedPro) return;
    setPatients(prev => prev.map(old => old.id === p.id ? p : old));
    await savePatient(p, loggedPro.id);
  }, [loggedPro]);

  // ── Transacciones ─────────────────────────────────────────
  const addTransaction = useCallback(async (t: Transaction) => {
    if (!loggedPro) return;
    setManualTransactions(prev => [...prev, t]);
    await saveTransaction(t, loggedPro.id);
  }, [loggedPro]);

  const deleteTransaction = useCallback(async (id: string) => {
    setManualTransactions(prev => prev.filter(t => t.id !== id));
    await dbDeleteTransaction(id);
  }, []);

  return (
    <ClinicContext.Provider value={{
      loggedPro, professionals, appointments, patients,
      manualTransactions, isLoading, notifications, templates, isAdmin,
      setLoggedPro, setIsAdmin, setProfessionals,
      setAppointments, setPatients, setManualTransactions,
      setNotifications, setTemplates,
      updatePro, logout, refreshData,
      addAppointment, updateAppointment, deleteAppointment,
      addPatient, updatePatient,
      addTransaction, deleteTransaction,
    }}>
      {children}
    </ClinicContext.Provider>
  );
};

export const useClinic = () => {
  const ctx = useContext(ClinicContext);
  if (!ctx) throw new Error('useClinic debe usarse dentro de ClinicProvider');
  return ctx;
};
