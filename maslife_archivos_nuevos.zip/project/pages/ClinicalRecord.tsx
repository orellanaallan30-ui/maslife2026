import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useClinic } from '../ClinicContext';
import { Patient } from '../types';
import { SOAPEntry, InformedConsent } from '../types_clinical';
import ClinicalSOAP from '../components/ClinicalSOAP';
import { ConsentSendPanel } from '../components/ConsentFlow';
import { supabase } from '../supabaseClient';
import { auditService } from '../auditService';

// ── Tabs del expediente ────────────────────────────────────────
type RecordTab = 'soap' | 'info' | 'attachments' | 'consent';

const TAB_CONFIG: { id: RecordTab; label: string; icon: string }[] = [
  { id: 'info',        label: 'Información',   icon: 'person'         },
  { id: 'soap',        label: 'Ficha SOAP',    icon: 'assignment'     },
  { id: 'consent',     label: 'Consentimiento', icon: 'health_and_safety' },
  { id: 'attachments', label: 'Archivos',       icon: 'attach_file'    },
];

const ClinicalRecord: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { patients, loggedPro, setPatients } = useClinic();

  const [activeTab, setActiveTab]           = useState<RecordTab>('soap');
  const [soapEntries, setSoapEntries]       = useState<SOAPEntry[]>([]);
  const [consent, setConsent]              = useState<InformedConsent | null>(null);
  const [loadingSOAP, setLoadingSOAP]      = useState(true);
  const [signatureBase64, setSignatureBase64] = useState<string | undefined>();

  const patient: Patient | undefined = patients.find(p => p.id === id);

  // ── Cargar SOAP entries desde Supabase ─────────────────────
  useEffect(() => {
    if (!id || !loggedPro) return;

    const loadData = async () => {
      setLoadingSOAP(true);
      try {
        // SOAP entries
        const { data: soapData, error: soapError } = await supabase
          .from('soap_entries')
          .select('*')
          .eq('patient_id', id)
          .eq('professional_id', loggedPro.id)
          .order('session_number', { ascending: false });

        if (!soapError && soapData) {
          setSoapEntries(soapData.map(mapDBtoSOAP));
        }

        // Consentimiento activo
        const { data: consentData } = await supabase
          .from('informed_consents')
          .select('*')
          .eq('patient_id', id)
          .eq('professional_id', loggedPro.id)
          .order('sent_at', { ascending: false })
          .limit(1)
          .maybeSingle();

        if (consentData) setConsent(consentData as unknown as InformedConsent);

        // Firma del profesional
        const { data: sigData } = await supabase
          .from('professional_signatures')
          .select('signature_image_b64')
          .eq('professional_id', loggedPro.id)
          .eq('is_validated', true)
          .maybeSingle();

        if (sigData) setSignatureBase64(sigData.signature_image_b64);

        // Audit: ver ficha
        auditService.log({
          userId: loggedPro.id,
          userName: loggedPro.name,
          action: 'PATIENT_VIEW',
          resourceId: id,
          resourceType: 'patient',
        });
      } finally {
        setLoadingSOAP(false);
      }
    };

    loadData();
  }, [id, loggedPro]);

  // ── Guardar SOAP entry ──────────────────────────────────────
  const handleSaveSOAP = async (entry: SOAPEntry) => {
    if (!loggedPro) return;
    const dbRow = mapSOAPtoDB(entry, loggedPro.id);

    const { error } = await supabase.from('soap_entries').upsert(dbRow);
    if (error) {
      console.error('[ClinicalRecord] Error guardando SOAP:', error.message);
      return;
    }

    setSoapEntries(prev => {
      const exists = prev.some(e => e.id === entry.id);
      return exists ? prev.map(e => e.id === entry.id ? entry : e) : [entry, ...prev];
    });

    // Actualizar last_visit del paciente
    if (entry.isLocked && patient) {
      const updated = { ...patient, lastVisit: entry.date };
      setPatients(prev => prev.map(p => p.id === patient.id ? updated : p));
      await supabase
        .from('patients')
        .update({ last_visit: entry.date })
        .eq('id', patient.id);
    }
  };

  if (!patient) return (
    <div className="flex-1 flex items-center justify-center">
      <div className="text-center">
        <span className="material-icons-round text-5xl text-slate-300">person_off</span>
        <p className="font-bold text-slate-500 mt-2">Paciente no encontrado</p>
        <button onClick={() => navigate('/pro/patients')}
          className="mt-4 px-4 py-2 bg-teal-500 text-white rounded-xl text-sm font-bold">
          Volver a pacientes
        </button>
      </div>
    </div>
  );

  const riskColors: Record<string, string> = {
    'Alto': 'bg-rose-100 text-rose-700 border-rose-200',
    'Medio': 'bg-amber-100 text-amber-700 border-amber-200',
    'Bajo': 'bg-emerald-100 text-emerald-700 border-emerald-200',
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* ── Header del paciente ── */}
      <div className="bg-white border-b border-slate-100 px-6 py-4 shrink-0">
        <div className="flex items-center gap-4">
          <button
            onClick={() => navigate('/pro/patients')}
            className="w-10 h-10 rounded-xl hover:bg-slate-100 flex items-center justify-center transition-all"
          >
            <span className="material-icons-round text-slate-600">arrow_back</span>
          </button>

          {/* Avatar */}
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-teal-400 to-teal-600 flex items-center justify-center shadow-lg shrink-0">
            {patient.avatar
              ? <img src={patient.avatar} className="w-full h-full rounded-2xl object-cover" alt={patient.name} />
              : <span className="text-white font-black text-xl">{patient.name.charAt(0)}</span>
            }
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-3 flex-wrap">
              <h1 className="font-black text-xl text-slate-900 truncate">{patient.name}</h1>
              <span className={`text-xs px-2.5 py-1 rounded-full font-bold border ${riskColors[patient.risk] || 'bg-slate-100 text-slate-600 border-slate-200'}`}>
                Riesgo {patient.risk}
              </span>
              {consent?.status === 'ACCEPTED' && (
                <span className="text-xs px-2.5 py-1 rounded-full font-bold bg-emerald-100 text-emerald-700 border border-emerald-200 flex items-center gap-1">
                  <span className="material-icons-round text-xs">task_alt</span>
                  Consentimiento firmado
                </span>
              )}
            </div>
            <div className="flex items-center gap-4 mt-1 flex-wrap">
              <span className="text-sm text-slate-500">{patient.rut}</span>
              <span className="text-sm text-slate-500">{patient.age} años · {patient.gender}</span>
              <span className="text-sm text-slate-500">{patient.prevision}</span>
              {patient.lastVisit && (
                <span className="text-xs text-slate-400">
                  Última visita: {new Date(patient.lastVisit).toLocaleDateString('es-CL')}
                </span>
              )}
            </div>
          </div>

          {/* Sesiones counter */}
          <div className="hidden md:flex flex-col items-center bg-teal-50 rounded-2xl px-4 py-2 shrink-0">
            <span className="font-black text-2xl text-teal-600">{soapEntries.length}</span>
            <span className="text-xs text-teal-500 font-bold">sesiones</span>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mt-4 overflow-x-auto hide-scrollbar">
          {TAB_CONFIG.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider
                whitespace-nowrap transition-all
                ${activeTab === tab.id
                  ? 'bg-teal-500 text-white shadow-md shadow-teal-500/20'
                  : 'text-slate-500 hover:bg-slate-100'}`}
            >
              <span className="material-icons-round text-sm">{tab.icon}</span>
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* ── Contenido de tabs ── */}
      <div className="flex-1 overflow-hidden">
        {/* ── TAB: SOAP ── */}
        {activeTab === 'soap' && (
          <div className="h-full overflow-y-auto p-6">
            {loadingSOAP ? (
              <div className="flex items-center justify-center h-32">
                <div className="w-8 h-8 border-4 border-teal-500/20 border-t-teal-500 rounded-full animate-spin" />
              </div>
            ) : loggedPro ? (
              <ClinicalSOAP
                patient={patient}
                loggedPro={loggedPro}
                existingEntries={soapEntries}
                onSave={handleSaveSOAP}
                signatureBase64={signatureBase64}
              />
            ) : (
              <div className="text-center py-12 text-slate-400">
                <span className="material-icons-round text-4xl block mb-2">lock</span>
                <p>Debes iniciar sesión como profesional</p>
              </div>
            )}
          </div>
        )}

        {/* ── TAB: Información ── */}
        {activeTab === 'info' && (
          <div className="h-full overflow-y-auto p-6">
            <div className="max-w-2xl mx-auto grid grid-cols-2 gap-4">
              {[
                { label: 'Email',              value: patient.email       },
                { label: 'Teléfono',           value: patient.phone       },
                { label: 'Fecha de nacimiento', value: patient.birthDate   },
                { label: 'Dirección',          value: patient.address     },
                { label: 'Previsión',          value: patient.prevision   },
                { label: 'Contacto emergencia', value: patient.emergencyContact },
              ].map(f => f.value ? (
                <div key={f.label} className="bg-white border-2 border-slate-100 rounded-2xl p-4">
                  <p className="text-xs font-black text-slate-400 uppercase mb-1">{f.label}</p>
                  <p className="font-bold text-slate-800 text-sm">{f.value}</p>
                </div>
              ) : null)}

              {/* Alergias */}
              {patient.allergies && patient.allergies.length > 0 && (
                <div className="col-span-2 bg-rose-50 border-2 border-rose-200 rounded-2xl p-4">
                  <p className="text-xs font-black text-rose-500 uppercase mb-2">⚠️ Alergias</p>
                  <div className="flex flex-wrap gap-2">
                    {patient.allergies.map(a => (
                      <span key={a} className="bg-rose-100 text-rose-700 px-3 py-1 rounded-full text-xs font-bold">{a}</span>
                    ))}
                  </div>
                </div>
              )}

              {/* Historia médica */}
              {patient.medicalHistory && (
                <div className="col-span-2 bg-white border-2 border-slate-100 rounded-2xl p-4">
                  <p className="text-xs font-black text-slate-400 uppercase mb-2">Historia Médica</p>
                  <p className="text-sm text-slate-600 leading-relaxed whitespace-pre-wrap">{patient.medicalHistory}</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ── TAB: Consentimiento ── */}
        {activeTab === 'consent' && (
          <div className="h-full overflow-y-auto p-6">
            <div className="max-w-lg mx-auto">
              {loggedPro && (
                <ConsentSendPanel
                  patient={patient}
                  loggedPro={loggedPro}
                  existingConsent={consent}
                  onSent={c => setConsent(c)}
                />
              )}

              {/* Historial de consentimientos */}
              {consent && (
                <div className="mt-4 bg-slate-50 rounded-2xl p-4">
                  <p className="text-xs font-black text-slate-500 uppercase mb-3">Detalle del registro</p>
                  <div className="space-y-2 text-xs text-slate-600">
                    <p><span className="font-bold">Enviado:</span> {new Date(consent.sentAt).toLocaleString('es-CL')}</p>
                    <p><span className="font-bold">Expira:</span> {new Date(consent.expiresAt).toLocaleString('es-CL')}</p>
                    {consent.acceptedAt && <p><span className="font-bold">Aceptado:</span> {new Date(consent.acceptedAt).toLocaleString('es-CL')}</p>}
                    {consent.ipAddress && <p><span className="font-bold">IP de aceptación:</span> {consent.ipAddress}</p>}
                    <p><span className="font-bold">Código:</span> <span className="font-mono">{consent.verificationCode}</span></p>
                    <p><span className="font-bold">Versión del texto:</span> {consent.templateVersion}</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ── TAB: Archivos ── */}
        {activeTab === 'attachments' && (
          <div className="h-full overflow-y-auto p-6">
            <div className="max-w-2xl mx-auto">
              {(!patient.attachments || patient.attachments.length === 0) ? (
                <div className="text-center py-16 text-slate-400">
                  <span className="material-icons-round text-5xl block mb-3">cloud_upload</span>
                  <p className="font-bold">Sin archivos adjuntos</p>
                  <p className="text-sm mt-1">Los documentos clínicos escaneados aparecerán aquí</p>
                </div>
              ) : (
                <div className="grid gap-3">
                  {patient.attachments.map((file: any) => (
                    <div key={file.id} className="bg-white border-2 border-slate-100 rounded-2xl p-4 flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center
                        ${file.type === 'pdf' ? 'bg-rose-100' : 'bg-blue-100'}`}>
                        <span className={`material-icons-round text-lg
                          ${file.type === 'pdf' ? 'text-rose-500' : 'text-blue-500'}`}>
                          {file.type === 'pdf' ? 'picture_as_pdf' : 'image'}
                        </span>
                      </div>
                      <div className="flex-1">
                        <p className="font-bold text-slate-800 text-sm">{file.name}</p>
                        <p className="text-xs text-slate-400">{file.size} · {new Date(file.date).toLocaleDateString('es-CL')}</p>
                      </div>
                      {file.url && (
                        <a href={file.url} target="_blank" rel="noopener noreferrer"
                          className="w-9 h-9 rounded-xl bg-slate-100 flex items-center justify-center hover:bg-teal-100 transition-all">
                          <span className="material-icons-round text-slate-500 text-base">open_in_new</span>
                        </a>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// ── Mappers DB ↔ SOAPEntry ─────────────────────────────────────
function mapDBtoSOAP(row: Record<string, unknown>): SOAPEntry {
  return {
    id: row.id as string,
    patientId: row.patient_id as string,
    professionalId: row.professional_id as string,
    sessionNumber: row.session_number as number,
    date: row.date as string,
    createdAt: row.created_at as string,
    signedAt: row.signed_at as string | undefined,
    signedByRut: row.signed_by_rut as string | undefined,
    signatureImageBase64: row.signature_image_b64 as string | undefined,
    subjective: row.subjective as string || '',
    objective: row.objective as string || '',
    assessment: row.assessment as string || '',
    plan: row.plan as string || '',
    diagnosis: row.diagnosis as string | undefined,
    icd10Code: row.icd10_code as string | undefined,
    prestacion_code: row.prestacion_code as string | undefined,
    sessionDurationMinutes: row.session_duration_min as number | undefined,
    vitalSigns: row.vital_signs as SOAPEntry['vitalSigns'],
    isLocked: row.is_locked as boolean,
    documentHash: row.document_hash as string | undefined,
    verificationCode: row.verification_code as string,
    additionalNotes: (row.additional_notes as SOAPEntry['additionalNotes']) || [],
  };
}

function mapSOAPtoDB(entry: SOAPEntry, professionalId: string) {
  return {
    id: entry.id,
    patient_id: entry.patientId,
    professional_id: professionalId,
    session_number: entry.sessionNumber,
    date: entry.date,
    created_at: entry.createdAt,
    signed_at: entry.signedAt || null,
    signed_by_rut: entry.signedByRut || null,
    signature_image_b64: entry.signatureImageBase64 || null,
    subjective: entry.subjective,
    objective: entry.objective,
    assessment: entry.assessment,
    plan: entry.plan,
    diagnosis: entry.diagnosis || null,
    icd10_code: entry.icd10Code || null,
    prestacion_code: entry.prestacion_code || null,
    session_duration_min: entry.sessionDurationMinutes || null,
    vital_signs: entry.vitalSigns || null,
    is_locked: entry.isLocked,
    document_hash: entry.documentHash || null,
    verification_code: entry.verificationCode,
  };
}

export default ClinicalRecord;
