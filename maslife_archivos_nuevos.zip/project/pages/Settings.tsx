import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useClinic } from '../ClinicContext';
import { ProfessionalProfile } from '../types';
import { supabase } from '../supabaseClient';
import { validateRUT, formatRUT, RUTInput, useRUTField } from '../rutValidator';
import { auditService } from '../auditService';

// ── Tabs ────────────────────────────────────────────────────────
type SettingsTab = 'profile' | 'signature' | 'schedule' | 'security';

const TABS: { id: SettingsTab; label: string; icon: string }[] = [
  { id: 'profile',   label: 'Perfil',          icon: 'person'        },
  { id: 'signature', label: 'Firma y Registro', icon: 'draw'          },
  { id: 'schedule',  label: 'Horario',          icon: 'calendar_today'},
  { id: 'security',  label: 'Seguridad',        icon: 'lock'          },
];

// ── Canvas de rúbrica ───────────────────────────────────────────
const SignatureCanvas: React.FC<{
  onCapture: (b64: string) => void;
  initialImage?: string;
}> = ({ onCapture, initialImage }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const drawing = useRef(false);
  const [hasDrawing, setHasDrawing] = useState(false);

  useEffect(() => {
    if (initialImage && canvasRef.current) {
      const ctx = canvasRef.current.getContext('2d');
      if (!ctx) return;
      const img = new Image();
      img.onload = () => {
        ctx.clearRect(0, 0, canvasRef.current!.width, canvasRef.current!.height);
        ctx.drawImage(img, 0, 0, canvasRef.current!.width, canvasRef.current!.height);
        setHasDrawing(true);
      };
      img.src = initialImage;
    }
  }, [initialImage]);

  const getPos = (e: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    if ('touches' in e) {
      return {
        x: (e.touches[0].clientX - rect.left) * scaleX,
        y: (e.touches[0].clientY - rect.top) * scaleY,
      };
    }
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY,
    };
  };

  const start = (e: React.MouseEvent | React.TouchEvent) => {
    drawing.current = true;
    const ctx = canvasRef.current!.getContext('2d')!;
    const pos = getPos(e);
    ctx.beginPath();
    ctx.moveTo(pos.x, pos.y);
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    if (!drawing.current) return;
    const ctx = canvasRef.current!.getContext('2d')!;
    const pos = getPos(e);
    ctx.lineTo(pos.x, pos.y);
    ctx.strokeStyle = '#0f172a';
    ctx.lineWidth = 2.5;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.stroke();
    setHasDrawing(true);
  };

  const end = () => {
    drawing.current = false;
    onCapture(canvasRef.current!.toDataURL('image/png'));
  };

  const clear = () => {
    const ctx = canvasRef.current!.getContext('2d')!;
    ctx.clearRect(0, 0, canvasRef.current!.width, canvasRef.current!.height);
    setHasDrawing(false);
    onCapture('');
  };

  return (
    <div className="flex flex-col gap-2">
      <canvas
        ref={canvasRef}
        width={500}
        height={150}
        className="w-full border-2 border-dashed border-slate-300 rounded-2xl bg-slate-50
          touch-none cursor-crosshair hover:border-teal-300 transition-colors"
        style={{ maxHeight: 150 }}
        onMouseDown={start} onMouseMove={draw} onMouseUp={end} onMouseLeave={end}
        onTouchStart={e => { e.preventDefault(); start(e); }}
        onTouchMove={e => { e.preventDefault(); draw(e); }}
        onTouchEnd={end}
      />
      <div className="flex items-center gap-3">
        {hasDrawing && (
          <button onClick={clear}
            className="text-xs text-slate-500 hover:text-rose-500 transition-colors flex items-center gap-1">
            <span className="material-icons-round text-xs">refresh</span>
            Limpiar
          </button>
        )}
        <p className="text-xs text-slate-400">
          Dibuja tu rúbrica habitual — se usará en los documentos firmados
        </p>
      </div>
    </div>
  );
};

// ── Panel de carga de imagen de firma ────────────────────────────
const SignatureImageUpload: React.FC<{
  current?: string;
  onChange: (b64: string) => void;
}> = ({ current, onChange }) => {
  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 500 * 1024) { alert('La imagen no debe superar 500KB'); return; }
    const reader = new FileReader();
    reader.onload = () => onChange(reader.result as string);
    reader.readAsDataURL(file);
  };

  return (
    <label className="flex flex-col items-center gap-3 p-6 border-2 border-dashed border-slate-200
      rounded-2xl bg-slate-50 cursor-pointer hover:border-teal-300 hover:bg-teal-50/30 transition-all">
      {current ? (
        <img src={current} alt="Firma actual" className="h-16 object-contain" />
      ) : (
        <span className="material-icons-round text-4xl text-slate-300">upload_file</span>
      )}
      <div className="text-center">
        <p className="text-sm font-black text-slate-600">
          {current ? 'Cambiar imagen de firma' : 'Cargar imagen de firma (PNG)'}
        </p>
        <p className="text-xs text-slate-400">PNG con fondo transparente · Máx 500KB</p>
      </div>
      <input type="file" accept="image/png" className="hidden" onChange={handleFile} />
    </label>
  );
};

// ── Settings principal ──────────────────────────────────────────
const Settings: React.FC = () => {
  const { loggedPro, updatePro } = useClinic();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<SettingsTab>('profile');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved]   = useState(false);
  const [toast, setToast]   = useState('');

  // ── Estado de perfil ─────────────────────────────────────────
  const [profile, setProfile] = useState<Partial<ProfessionalProfile>>(loggedPro || {});

  // ── Estado de firma ──────────────────────────────────────────
  const [signatureMode, setSignatureMode]   = useState<'draw' | 'upload'>('draw');
  const [signatureB64, setSignatureB64]     = useState('');
  const [existingSignature, setExistingSignature] = useState<string | undefined>();
  const rutField = useRUTField(loggedPro?.rut || '');
  const [superRegNum, setSuperRegNum]       = useState('');
  const [sigValidated, setSigValidated]     = useState(false);
  const [sigSaving, setSigSaving]           = useState(false);

  // ── Estado de seguridad ──────────────────────────────────────
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass]         = useState('');
  const [confirmPass, setConfirmPass] = useState('');

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(''), 3000);
  };

  // Cargar firma existente
  useEffect(() => {
    if (!loggedPro) return;
    supabase
      .from('professional_signatures')
      .select('*')
      .eq('professional_id', loggedPro.id)
      .maybeSingle()
      .then(({ data }) => {
        if (data) {
          setExistingSignature(data.signature_image_b64);
          setSignatureB64(data.signature_image_b64);
          setSuperRegNum(data.superintendencia_reg_number || '');
          setSigValidated(data.is_validated || false);
        }
      });
  }, [loggedPro]);

  // ── Guardar perfil ───────────────────────────────────────────
  const handleSaveProfile = async () => {
    if (!loggedPro) return;
    setSaving(true);
    try {
      const updated = { ...loggedPro, ...profile } as ProfessionalProfile;
      updatePro(updated);
      showToast('✅ Perfil guardado');
    } finally {
      setSaving(false);
    }
  };

  // ── Guardar firma ────────────────────────────────────────────
  const handleSaveSignature = async () => {
    if (!loggedPro) return;

    if (!signatureB64) {
      showToast('❌ Dibuja o carga tu firma primero');
      return;
    }

    const rutValidation = validateRUT(rutField.raw);
    if (!rutValidation.valid) {
      showToast(`❌ RUT inválido: ${rutValidation.error}`);
      return;
    }

    if (!superRegNum.trim()) {
      showToast('❌ El Nº de Registro Superintendencia es obligatorio');
      return;
    }

    setSigSaving(true);
    try {
      const { error } = await supabase.from('professional_signatures').upsert({
        professional_id: loggedPro.id,
        rut: rutValidation.formatted,
        superintendencia_reg_number: superRegNum.trim(),
        signature_image_b64: signatureB64,
        uploaded_at: new Date().toISOString(),
        is_validated: false,  // Admin debe validar
      });

      if (error) throw error;

      // Actualizar perfil con el RUT
      updatePro({ ...loggedPro, rut: rutValidation.formatted });
      setExistingSignature(signatureB64);
      setSigValidated(false);

      auditService.log({
        userId: loggedPro.id,
        userName: loggedPro.name,
        action: 'SOAP_SIGN', // reutilizamos como acción de registro
        resourceId: loggedPro.id,
        resourceType: 'document',
        details: { action: 'SIGNATURE_UPLOAD', rut: rutValidation.formatted },
      });

      showToast('✅ Firma guardada — pendiente de validación por admin');
    } catch (err) {
      showToast('❌ Error al guardar la firma');
    } finally {
      setSigSaving(false);
    }
  };

  // ── Cambiar contraseña ────────────────────────────────────────
  const handleChangePassword = async () => {
    if (!loggedPro) return;
    if (newPass.length < 8) { showToast('❌ La nueva contraseña debe tener al menos 8 caracteres'); return; }
    if (newPass !== confirmPass) { showToast('❌ Las contraseñas no coinciden'); return; }
    if (currentPass === newPass) { showToast('❌ La nueva contraseña debe ser diferente'); return; }

    // Verificar contraseña actual (simple — idealmente via Edge Function con bcrypt)
    const { hashPassword, verifyPassword } = await import('../supabaseService');
    const isValid = await verifyPassword(currentPass, loggedPro.password || '');
    if (!isValid) { showToast('❌ Contraseña actual incorrecta'); return; }

    const newHash = await hashPassword(newPass);
    updatePro({ ...loggedPro, password: newHash, needsPasswordReset: false });
    setCurrentPass(''); setNewPass(''); setConfirmPass('');
    showToast('✅ Contraseña actualizada correctamente');
  };

  if (!loggedPro) return null;

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-slate-50">
      {/* Toast */}
      {toast && (
        <div className="fixed top-6 right-6 z-50 bg-slate-900 text-white px-5 py-3 rounded-2xl
          shadow-2xl text-sm font-bold animate-in slide-in-from-top-2">
          {toast}
        </div>
      )}

      {/* Header */}
      <div className="bg-white border-b border-slate-100 px-6 py-4 shrink-0">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl overflow-hidden border-2 border-slate-200 shrink-0">
            <img src={loggedPro.avatar || 'https://picsum.photos/seed/pro/64/64'} className="w-full h-full object-cover" alt="" />
          </div>
          <div>
            <h1 className="font-black text-xl text-slate-900">{loggedPro.name}</h1>
            <p className="text-sm text-slate-500">{loggedPro.specialty} · {loggedPro.city}</p>
          </div>
        </div>

        <div className="flex gap-1 mt-4 overflow-x-auto hide-scrollbar">
          {TABS.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider
                whitespace-nowrap transition-all
                ${activeTab === tab.id
                  ? 'bg-teal-500 text-white shadow-md'
                  : 'text-slate-500 hover:bg-slate-100'}`}
            >
              <span className="material-icons-round text-sm">{tab.icon}</span>
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-2xl mx-auto">

          {/* ── TAB: Perfil ── */}
          {activeTab === 'profile' && (
            <div className="flex flex-col gap-4">
              <SectionCard title="Información Personal">
                <div className="grid grid-cols-2 gap-4">
                  <Field label="Nombre completo" value={profile.name || ''} onChange={v => setProfile(p => ({ ...p, name: v }))} />
                  <Field label="Especialidad" value={profile.specialty || ''} onChange={v => setProfile(p => ({ ...p, specialty: v }))} />
                  <Field label="Ciudad" value={profile.city || ''} onChange={v => setProfile(p => ({ ...p, city: v }))} />
                  <Field label="Email" value={profile.email || ''} onChange={v => setProfile(p => ({ ...p, email: v }))} type="email" />
                </div>
                <Field label="Biografía" value={profile.bio || ''} onChange={v => setProfile(p => ({ ...p, bio: v }))} textarea />
              </SectionCard>

              <SectionCard title="URL del Avatar">
                <Field label="URL de imagen" value={profile.avatar || ''} onChange={v => setProfile(p => ({ ...p, avatar: v }))} />
                {profile.avatar && (
                  <div className="mt-3 flex items-center gap-3">
                    <img src={profile.avatar} className="w-16 h-16 rounded-2xl object-cover border-2 border-slate-200" alt="" />
                    <p className="text-xs text-slate-500">Vista previa del avatar</p>
                  </div>
                )}
              </SectionCard>

              <button
                onClick={handleSaveProfile}
                disabled={saving}
                className="w-full py-3.5 bg-teal-500 text-white rounded-2xl font-black
                  hover:bg-teal-600 transition-all disabled:opacity-60 flex items-center justify-center gap-2"
              >
                <span className="material-icons-round text-base">{saving ? 'sync' : 'save'}</span>
                {saving ? 'Guardando...' : 'Guardar Perfil'}
              </button>
            </div>
          )}

          {/* ── TAB: Firma y Registro ── */}
          {activeTab === 'signature' && (
            <div className="flex flex-col gap-4">
              {/* Estado de validación */}
              {existingSignature && (
                <div className={`rounded-2xl p-4 flex items-center gap-3 border-2
                  ${sigValidated
                    ? 'bg-emerald-50 border-emerald-200'
                    : 'bg-amber-50 border-amber-200'}`}>
                  <span className={`material-icons-round text-2xl ${sigValidated ? 'text-emerald-500' : 'text-amber-500'}`}>
                    {sigValidated ? 'verified' : 'pending'}
                  </span>
                  <div>
                    <p className={`font-black text-sm ${sigValidated ? 'text-emerald-700' : 'text-amber-700'}`}>
                      {sigValidated ? 'Firma validada — Documentos habilitados' : 'Firma pendiente de validación por administrador'}
                    </p>
                    <p className={`text-xs ${sigValidated ? 'text-emerald-600' : 'text-amber-600'}`}>
                      {sigValidated
                        ? 'Los PDFs exportados incluirán tu rúbrica y registro oficial'
                        : 'El admin debe confirmar tu Nº de Registro de la Superintendencia de Salud'}
                    </p>
                  </div>
                </div>
              )}

              {/* RUT y registro */}
              <SectionCard title="Identificación del Prestador">
                <RUTInput
                  label="RUT del profesional"
                  value={rutField.value}
                  onChange={rutField.onChange}
                  onBlur={rutField.onBlur}
                  valid={rutField.valid}
                  error={rutField.error}
                  required
                />
                <div className="mt-4">
                  <label className="block text-xs font-black text-slate-500 uppercase tracking-wider mb-1">
                    Nº Registro Superintendencia de Salud <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={superRegNum}
                    onChange={e => setSuperRegNum(e.target.value)}
                    placeholder="Ej: 12345"
                    className="w-full border-2 border-slate-200 rounded-xl px-3 py-2.5 text-sm font-bold
                      text-slate-800 outline-none focus:border-teal-400 transition-colors"
                  />
                  <p className="text-xs text-slate-400 mt-1">
                    Búscalo en <a href="https://rnpi.superdesalud.gob.cl" target="_blank" rel="noopener noreferrer"
                      className="text-teal-500 hover:underline">rnpi.superdesalud.gob.cl</a>
                  </p>
                </div>
              </SectionCard>

              {/* Rúbrica */}
              <SectionCard title="Rúbrica Digital">
                {/* Toggle modo */}
                <div className="flex gap-2 mb-4">
                  {(['draw', 'upload'] as const).map(mode => (
                    <button
                      key={mode}
                      onClick={() => setSignatureMode(mode)}
                      className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black transition-all
                        ${signatureMode === mode ? 'bg-teal-500 text-white' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'}`}
                    >
                      <span className="material-icons-round text-sm">
                        {mode === 'draw' ? 'draw' : 'upload'}
                      </span>
                      {mode === 'draw' ? 'Dibujar' : 'Cargar PNG'}
                    </button>
                  ))}
                </div>

                {signatureMode === 'draw' ? (
                  <SignatureCanvas
                    onCapture={setSignatureB64}
                    initialImage={existingSignature}
                  />
                ) : (
                  <SignatureImageUpload
                    current={existingSignature}
                    onChange={setSignatureB64}
                  />
                )}

                {signatureB64 && (
                  <div className="mt-4 bg-slate-50 rounded-xl p-3">
                    <p className="text-xs font-black text-slate-500 mb-2">Vista previa en documento:</p>
                    <div className="bg-white border border-slate-200 rounded-lg p-3 inline-block">
                      <img src={signatureB64} alt="Preview" className="h-12 object-contain" />
                      <p className="text-xs text-slate-500 mt-1">{loggedPro.name}</p>
                    </div>
                  </div>
                )}
              </SectionCard>

              <button
                onClick={handleSaveSignature}
                disabled={sigSaving}
                className="w-full py-3.5 bg-teal-500 text-white rounded-2xl font-black
                  hover:bg-teal-600 transition-all disabled:opacity-60 flex items-center justify-center gap-2"
              >
                <span className={`material-icons-round text-base ${sigSaving ? 'animate-spin' : ''}`}>
                  {sigSaving ? 'sync' : 'verified'}
                </span>
                {sigSaving ? 'Guardando...' : 'Guardar Firma y Registro'}
              </button>

              <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4">
                <p className="text-xs font-bold text-blue-700 flex items-start gap-2">
                  <span className="material-icons-round text-base shrink-0">info</span>
                  La firma quedará en estado "Pendiente" hasta que el administrador valide tu
                  Nº de Registro en la Superintendencia de Salud. Solo firmas validadas se incluyen
                  en documentos para reembolso Fonasa/Isapre.
                </p>
              </div>
            </div>
          )}

          {/* ── TAB: Seguridad ── */}
          {activeTab === 'security' && (
            <div className="flex flex-col gap-4">
              <SectionCard title="Cambiar Contraseña">
                <div className="flex flex-col gap-3">
                  <PasswordField label="Contraseña actual" value={currentPass} onChange={setCurrentPass} />
                  <PasswordField label="Nueva contraseña (mín. 8 caracteres)" value={newPass} onChange={setNewPass} />
                  <PasswordField label="Confirmar nueva contraseña" value={confirmPass} onChange={setConfirmPass} />

                  {/* Indicador de fortaleza */}
                  {newPass && (
                    <PasswordStrength password={newPass} />
                  )}
                </div>
              </SectionCard>

              <button
                onClick={handleChangePassword}
                disabled={!currentPass || !newPass || !confirmPass}
                className="w-full py-3.5 bg-slate-800 text-white rounded-2xl font-black
                  hover:bg-slate-900 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
              >
                <span className="material-icons-round text-base">lock_reset</span>
                Actualizar Contraseña
              </button>

              {/* Info de seguridad */}
              <SectionCard title="Estado de Seguridad">
                <div className="space-y-3">
                  <SecurityRow icon="key" label="Contraseña hasheada" ok={true} />
                  <SecurityRow icon="verified_user" label="Registro Superint. Salud" ok={sigValidated} />
                  <SecurityRow icon="draw" label="Firma digital configurada" ok={!!existingSignature} />
                  <SecurityRow icon="cloud" label="Datos en nube Supabase" ok={true} />
                </div>
              </SectionCard>
            </div>
          )}

          {/* ── TAB: Horario ── */}
          {activeTab === 'schedule' && (
            <SectionCard title="Horario de Atención">
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-xs font-black text-slate-500 uppercase mb-1">Hora inicio</label>
                  <input
                    type="time"
                    value={profile.workingHours?.start || '08:00'}
                    onChange={e => setProfile(p => ({ ...p, workingHours: { ...p.workingHours!, start: e.target.value } }))}
                    className="w-full border-2 border-slate-200 rounded-xl px-3 py-2.5 text-sm font-bold outline-none focus:border-teal-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-black text-slate-500 uppercase mb-1">Hora fin</label>
                  <input
                    type="time"
                    value={profile.workingHours?.end || '20:00'}
                    onChange={e => setProfile(p => ({ ...p, workingHours: { ...p.workingHours!, end: e.target.value } }))}
                    className="w-full border-2 border-slate-200 rounded-xl px-3 py-2.5 text-sm font-bold outline-none focus:border-teal-400"
                  />
                </div>
              </div>
              <button
                onClick={handleSaveProfile}
                className="w-full py-3 bg-teal-500 text-white rounded-xl font-black hover:bg-teal-600 transition-all"
              >
                Guardar Horario
              </button>
            </SectionCard>
          )}
        </div>
      </div>
    </div>
  );
};

// ── Subcomponentes ──────────────────────────────────────────────
const SectionCard: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="bg-white rounded-2xl border-2 border-slate-100 p-5">
    <h3 className="font-black text-sm text-slate-700 uppercase tracking-wider mb-4">{title}</h3>
    {children}
  </div>
);

const Field: React.FC<{
  label: string; value: string; onChange: (v: string) => void;
  type?: string; textarea?: boolean;
}> = ({ label, value, onChange, type = 'text', textarea = false }) => (
  <div className={textarea ? 'col-span-2' : ''}>
    <label className="block text-xs font-black text-slate-500 uppercase tracking-wider mb-1">{label}</label>
    {textarea ? (
      <textarea value={value} onChange={e => onChange(e.target.value)} rows={3}
        className="w-full border-2 border-slate-200 rounded-xl px-3 py-2.5 text-sm font-medium
          text-slate-800 outline-none focus:border-teal-400 resize-none" />
    ) : (
      <input type={type} value={value} onChange={e => onChange(e.target.value)}
        className="w-full border-2 border-slate-200 rounded-xl px-3 py-2.5 text-sm font-medium
          text-slate-800 outline-none focus:border-teal-400" />
    )}
  </div>
);

const PasswordField: React.FC<{ label: string; value: string; onChange: (v: string) => void }> = ({ label, value, onChange }) => {
  const [show, setShow] = useState(false);
  return (
    <div>
      <label className="block text-xs font-black text-slate-500 uppercase tracking-wider mb-1">{label}</label>
      <div className="relative">
        <input type={show ? 'text' : 'password'} value={value} onChange={e => onChange(e.target.value)}
          className="w-full border-2 border-slate-200 rounded-xl px-3 py-2.5 text-sm font-medium
            text-slate-800 outline-none focus:border-teal-400 pr-10" />
        <button onClick={() => setShow(!show)} type="button"
          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
          <span className="material-icons-round text-lg">{show ? 'visibility_off' : 'visibility'}</span>
        </button>
      </div>
    </div>
  );
};

const PasswordStrength: React.FC<{ password: string }> = ({ password }) => {
  const checks = [
    { label: 'Al menos 8 caracteres', ok: password.length >= 8 },
    { label: 'Letra mayúscula', ok: /[A-Z]/.test(password) },
    { label: 'Número', ok: /[0-9]/.test(password) },
    { label: 'Carácter especial', ok: /[!@#$%^&*(),.?":{}|<>]/.test(password) },
  ];
  const score = checks.filter(c => c.ok).length;
  const colors = ['bg-rose-400', 'bg-orange-400', 'bg-amber-400', 'bg-emerald-400'];

  return (
    <div className="bg-slate-50 rounded-xl p-3">
      <div className="flex gap-1 mb-2">
        {[0,1,2,3].map(i => (
          <div key={i} className={`h-1.5 flex-1 rounded-full transition-all ${i < score ? colors[score - 1] : 'bg-slate-200'}`} />
        ))}
      </div>
      <div className="grid grid-cols-2 gap-1">
        {checks.map(c => (
          <p key={c.label} className={`text-xs flex items-center gap-1 ${c.ok ? 'text-emerald-600' : 'text-slate-400'}`}>
            <span className="material-icons-round text-xs">{c.ok ? 'check_circle' : 'radio_button_unchecked'}</span>
            {c.label}
          </p>
        ))}
      </div>
    </div>
  );
};

const SecurityRow: React.FC<{ icon: string; label: string; ok: boolean }> = ({ icon, label, ok }) => (
  <div className="flex items-center justify-between py-2 border-b border-slate-50 last:border-0">
    <div className="flex items-center gap-3">
      <span className="material-icons-round text-slate-400 text-base">{icon}</span>
      <span className="text-sm text-slate-600 font-medium">{label}</span>
    </div>
    <span className={`text-xs px-2.5 py-1 rounded-full font-bold ${ok ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
      {ok ? '✓ Activo' : '⚠ Pendiente'}
    </span>
  </div>
);

export default Settings;
