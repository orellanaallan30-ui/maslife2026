import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useClinic } from '../ClinicContext';
import { loginProfessional, checkRateLimit } from '../supabaseService';

// ── Indicador de fortaleza de contraseña ──────────────────────
const StrengthBar: React.FC<{ password: string }> = ({ password: p }) => {
  const checks = [p.length >= 8, /[A-Z]/.test(p), /[0-9]/.test(p), /[^a-zA-Z0-9]/.test(p)];
  const score = checks.filter(Boolean).length;
  const labels = ['', 'Débil', 'Regular', 'Buena', 'Excelente'];
  const colors = ['', 'bg-rose-400', 'bg-amber-400', 'bg-teal-400', 'bg-emerald-500'];
  if (!p) return null;
  return (
    <div className="mt-2">
      <div className="flex gap-1 mb-1">
        {[1,2,3,4].map(i => (
          <div key={i} className={`h-1 flex-1 rounded-full transition-all duration-300
            ${i <= score ? colors[score] : 'bg-slate-200'}`} />
        ))}
      </div>
      <p className={`text-xs font-bold ${score >= 3 ? 'text-emerald-600' : score === 2 ? 'text-amber-600' : 'text-rose-500'}`}>
        {labels[score]}
      </p>
    </div>
  );
};

// ── Campo de contraseña con toggle ────────────────────────────
const PasswordField: React.FC<{
  label: string; value: string; onChange: (v: string) => void;
  placeholder?: string; showStrength?: boolean; disabled?: boolean;
  autoComplete?: string;
}> = ({ label, value, onChange, placeholder, showStrength, disabled, autoComplete = 'current-password' }) => {
  const [show, setShow] = useState(false);
  return (
    <div>
      <label className="block text-xs font-black text-slate-600 uppercase tracking-wider mb-1.5">{label}</label>
      <div className="relative">
        <input
          type={show ? 'text' : 'password'}
          value={value}
          onChange={e => onChange(e.target.value)}
          placeholder={placeholder}
          disabled={disabled}
          autoComplete={autoComplete}
          className="w-full bg-slate-50 border-2 border-slate-200 rounded-2xl px-4 py-3.5 pr-12 text-sm
            font-medium text-slate-800 outline-none focus:border-teal-500 focus:bg-white
            transition-all placeholder:text-slate-400 disabled:opacity-50"
        />
        <button type="button" onClick={() => setShow(s => !s)}
          className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-teal-500 transition-colors">
          <span className="material-icons-round text-xl">{show ? 'visibility_off' : 'visibility'}</span>
        </button>
      </div>
      {showStrength && <StrengthBar password={value} />}
    </div>
  );
};

// ── Countdown timer para rate limit ───────────────────────────
const RateCountdown: React.FC<{ remainingMs: number; onExpire: () => void }> = ({ remainingMs, onExpire }) => {
  const [left, setLeft] = useState(remainingMs);
  useEffect(() => {
    const t = setInterval(() => {
      setLeft(prev => { if (prev <= 1000) { clearInterval(t); onExpire(); return 0; } return prev - 1000; });
    }, 1000);
    return () => clearInterval(t);
  }, [onExpire]);
  const min = Math.floor(left / 60000);
  const sec = Math.floor((left % 60000) / 1000);
  return (
    <div className="bg-rose-50 border-2 border-rose-200 rounded-2xl p-4 text-center">
      <span className="material-icons-round text-rose-500 text-3xl block mb-2">lock_clock</span>
      <p className="font-black text-rose-700 text-sm">Cuenta bloqueada temporalmente</p>
      <p className="text-rose-600 text-xs mt-1">Intenta de nuevo en</p>
      <p className="font-mono font-black text-rose-700 text-2xl mt-1">
        {String(min).padStart(2,'0')}:{String(sec).padStart(2,'0')}
      </p>
    </div>
  );
};

// ── ProfessionalLogin ─────────────────────────────────────────
const ProfessionalLogin: React.FC = () => {
  const navigate = useNavigate();
  const { setLoggedPro } = useClinic();

  const [email, setEmail]       = useState('');
  const [password, setPassword] = useState('');
  const [error, setError]       = useState('');
  const [loading, setLoading]   = useState(false);
  const [rlState, setRlState]   = useState(() => checkRateLimit());

  const blocked = rlState.blocked && rlState.remainingMs > 0;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email.trim() || !password) { setError('Completa todos los campos.'); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { setError('Email inválido.'); return; }

    setLoading(true);
    try {
      const result = await loginProfessional(email.trim().toLowerCase(), password);
      if (result.error) {
        setError(result.error);
        setRlState(checkRateLimit());
      } else if (result.pro) {
        setLoggedPro(result.pro);
        if (result.pro.needsPasswordReset) navigate('/pro/password-setup');
        else navigate('/pro/dashboard');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      {/* Fondo decorativo */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-teal-500/8 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-teal-500/5 rounded-full blur-3xl" />
      </div>

      <div className="w-full max-w-md relative">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-3 mb-4">
            <div className="bg-teal-500 w-14 h-14 rounded-2xl flex items-center justify-center shadow-xl shadow-teal-500/30">
              <span className="material-icons-round text-white text-3xl">medical_services</span>
            </div>
            <div className="text-left">
              <p className="text-xs font-black text-teal-600 uppercase tracking-widest">PLATAFORMA</p>
              <p className="text-2xl font-black text-slate-900">Mas Life 🧡</p>
            </div>
          </div>
          <h1 className="text-xl font-black text-slate-800">Acceso Profesional</h1>
          <p className="text-sm text-slate-500 mt-1">Ingresa a tu panel de gestión clínica</p>
        </div>

        {/* Card */}
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xl shadow-slate-900/5 p-8">
          {blocked ? (
            <RateCountdown remainingMs={rlState.remainingMs} onExpire={() => setRlState(checkRateLimit())} />
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col gap-5" noValidate>
              {/* Email */}
              <div>
                <label className="block text-xs font-black text-slate-600 uppercase tracking-wider mb-1.5">
                  Email profesional
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="tu@email.com"
                  autoComplete="username"
                  disabled={loading}
                  className="w-full bg-slate-50 border-2 border-slate-200 rounded-2xl px-4 py-3.5 text-sm
                    font-medium text-slate-800 outline-none focus:border-teal-500 focus:bg-white
                    transition-all placeholder:text-slate-400 disabled:opacity-50"
                />
              </div>

              {/* Contraseña */}
              <PasswordField
                label="Contraseña"
                value={password}
                onChange={setPassword}
                placeholder="••••••••"
                disabled={loading}
              />

              {/* Error */}
              {error && (
                <div className="bg-rose-50 border border-rose-200 rounded-xl px-4 py-3 flex items-center gap-2">
                  <span className="material-icons-round text-rose-500 text-base">error</span>
                  <p className="text-sm text-rose-700 font-medium">{error}</p>
                </div>
              )}

              {/* CTA */}
              <button
                type="submit"
                disabled={loading}
                className="w-full py-4 bg-teal-500 text-white rounded-2xl font-black text-sm
                  hover:bg-teal-600 active:scale-95 transition-all disabled:opacity-60
                  flex items-center justify-center gap-2 shadow-lg shadow-teal-500/25 mt-1"
              >
                {loading ? (
                  <><span className="material-icons-round text-base animate-spin">sync</span>Verificando...</>
                ) : (
                  <><span className="material-icons-round text-base">login</span>Ingresar al panel</>
                )}
              </button>

              {/* Links */}
              <div className="flex flex-col items-center gap-2 pt-1">
                <Link to="/pro/recover"
                  className="text-sm text-teal-600 hover:text-teal-800 font-bold transition-colors">
                  ¿Olvidaste tu contraseña?
                </Link>
                <p className="text-sm text-slate-500">
                  ¿No tienes cuenta?{' '}
                  <Link to="/pro/register" className="text-teal-600 font-bold hover:text-teal-800 transition-colors">
                    Regístrate gratis
                  </Link>
                </p>
              </div>
            </form>
          )}
        </div>

        {/* Intentos restantes */}
        {!blocked && rlState.remainingMs === 0 && (
          <p className="text-center text-xs text-slate-400 mt-4">
            Protegido contra accesos no autorizados · www.clinicamaslife.cl
          </p>
        )}
      </div>
    </div>
  );
};

export default ProfessionalLogin;
